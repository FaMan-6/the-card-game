package com.faman_akira.thegamechatgpt

data class CardData(
    val drawable: Int,
    var isMatched: Boolean = false,
    var isFlipped: Boolean = false
)
